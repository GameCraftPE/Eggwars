# Plugin coding: Enes5519 & Driesboy
# Only works on PMMP
# Test server: gamecraftpe.tk

[![Poggit-CI](https://poggit.pmmp.io/ci.badge/NL-4-DEVS/Eggwars/Eggwars)](https://poggit.pmmp.io/ci/NL-4-DEVS/Eggwars/Eggwars)

[Latest Release](https://poggit.pmmp.io/ci/NL-4-DEVS/Eggwars/Eggwars)


If you have lagg drops use [this plugin](https://github.com/thebigsmileXD/ItemStacks) to stack your items

## How to spawn the Eggwars Shop
### - /ew shop

## How to setup the Generator with a sign

#### First Line: generator
#### Second Line: Iron , Gold or Diamond
#### Third Line: Broken (If generator need to be broken)

## How to setup the team egg
### Place the Dragon Egg on the top of the team color wool.

## How to create a arena
### /ew create <arena> <teams> <PlayersPerTeam>

## How to set a team spawn
### /ew set <arena> <teamcolor>

## All the colors
### - ORANGE
### - PURPLE
### - LIGHT-BLUE
### - YELLOW
### - GREEN
### - GRAY
### - BLUE
### - RED

## How to set the waitinglobby
### /ew lobby <arena>

## How to save the map
### /ew save <arena>
